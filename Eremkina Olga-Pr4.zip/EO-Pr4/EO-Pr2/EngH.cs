﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EO_Pr4
{
    [My(Types ="English", Work = "Manager")]
    class EngH : Human
    {

        public EngH()
        {
            Name = "Marvin";         
            
        }
        public override void Origin()
        {
            Console.WriteLine("My country is Great Britan");
        }

        public override void SayHi()
        {
            Console.WriteLine("Hello!");
        }
    }
}
