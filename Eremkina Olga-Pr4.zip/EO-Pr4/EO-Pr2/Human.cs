﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EO_Pr4
{
    abstract class Human
    {
        private string N = "NoName";       

        public string Name
        {
            get { return N; }
            set { this.N = value; }
        }

        public int Age { get; set; }
        //public string Type { get; protected set; }

        public abstract void Origin();
        public abstract void SayHi();        
    }
}
