﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EO_Pr4
{
    class PrintI
    {
        public static void PrintInfo(Type t)
        {

            MyAttribute at = MyAttribute.GetCustomAttribute(t, typeof(MyAttribute)) as MyAttribute;

            Console.WriteLine("{0} works as {1}", at.Types, at.Work);
        }
    }
}
