﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EO_Pr4
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Human> humans = new List<Human>();
            humans.Add(new RusH());
            humans.Add(new EngH());
            humans.Add(new FranH());
            RusH R = new RusH();
            EngH E = new EngH();
            FranH F = new FranH();
            humans.Add(R);
            humans.Add(E);
            humans.Add(F);
            R.Name = "Иван";
            F.Name = "Oliver";
            E.Name = "Paul";

            foreach (Human h in humans)
            {
                try
                {
                    Console.Write("Введите возраст для {0}:", h.Name);
                    h.Age = int.Parse(Console.ReadLine());
                }
                catch (FormatException ex)
                {
                    Console.WriteLine("Возраст должен быть цифрой\n {0}", ex.Message);
                    Console.Write("Введите еще раз возраст для {0}:", h.Name);
                    h.Age = int.Parse(Console.ReadLine());
                }

            }
            Console.WriteLine();

            PrintI.PrintInfo(typeof(RusH));
            PrintI.PrintInfo(typeof(EngH));
            PrintI.PrintInfo(typeof(FranH));


            Console.WriteLine();
            Console.WriteLine("Коллекция:");
            foreach (Human h in humans)
            {
                Console.WriteLine("{0} - {1}", h.Name, h.Age);
            }

            Console.WriteLine();
            Console.WriteLine("Отсортированная коллекция по возрасту:");
            humans.Sort(delegate (Human h1, Human h2)
            { return h1.Age.CompareTo(h2.Age); });


            foreach (Human g in humans)
                Console.WriteLine("{0} - {1}", g.Name, g.Age);

            Console.ReadKey();
        }
        
    }
}

