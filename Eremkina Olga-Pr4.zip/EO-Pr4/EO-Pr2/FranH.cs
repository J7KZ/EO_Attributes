﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EO_Pr4
{
    [My(Types ="Le français", Work = "White Collar")]
    class FranH : Human
    {

        public FranH()
        {
            Name = "Joe";            
            
        }
        public override void Origin()
        {
           Console.WriteLine("Mon pays la France");
        }

        public override void SayHi()
        {
            Console.WriteLine("Salut!");
        }
    }
}
