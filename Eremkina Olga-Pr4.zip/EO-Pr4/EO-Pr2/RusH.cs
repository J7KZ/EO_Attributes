﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EO_Pr4
{
    [My(Types = "Russian", Work = "Student")]
    class RusH : Human
    {
        
        public RusH ()
        {
            Name = "Федор";           
           
        }
        public override void Origin()
        {
            Console.WriteLine("Моя страна Россия");
        }
        public override void SayHi()
        {
            Console.WriteLine ("Привет!");
            
        }        
    }
}
