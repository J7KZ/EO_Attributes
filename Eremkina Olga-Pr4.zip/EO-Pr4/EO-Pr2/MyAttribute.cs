﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EO_Pr4
{
    class MyAttribute : Attribute
    {
        public string Work { get; set; }
       

        public string Types { get; set; }

        
    }
}




