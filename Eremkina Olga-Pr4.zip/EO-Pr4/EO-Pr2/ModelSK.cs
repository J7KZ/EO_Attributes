﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EO_Pr2
{
    class ModelSK : Models
    {
        public void RS(int s)
        {
            int size;
            int pr;
            s = size * pr;
        }
    }
}
